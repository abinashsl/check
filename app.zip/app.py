from flask import Flask, render_template, request, redirect, url_for, make_response
from db import *

app = Flask(__name__)

def set_no_cache_headers(response):
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    return response

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def process():
    username = request.form['username']
    password = request.form['password']

    out = search(username, password)

    if out == 'Logged IN':
        # Redirect to another webpage
        response = make_response(redirect(url_for('success')))
    elif out == 'Check Password':
        response = make_response(redirect(url_for('pwderror')))
    else:
        # Values are incorrect, you can handle it as needed
        return render_template('error.html')

    return set_no_cache_headers(response)

@app.route('/success')
def success():
    response = make_response(render_template('questions.html'))
    return set_no_cache_headers(response)

@app.route('/pwderror')
def pwderror():
    response = make_response(render_template('pwderror.html'))
    return set_no_cache_headers(response)

@app.route('/submit', methods=['POST'])
def submit():
    return 'Thanks! for Submission. Check Your mail for Results.'

if __name__ == '__main__':
    app.run(debug=True)